//
//  ShiftAction.swift
//  ShiftPro
//
//  Created by Doris Wen on 2025/7/9.
//

import Foundation

enum ShiftAction {
    case editVacation
    case clearVacation
//    case dayShift
//    case nightShift
//    case addShift
//    case shiftCycle
}
