//
//  EmployeeCalendarView.swift
//  ShiftPro
//
//  Created by Doris Wen on 2025/7/8.
//

import SwiftUI

struct EmployeeCalendarView: View {
    @ObservedObject var controller: CalendarController = CalendarController(orientation: .vertical)
    @State private var isBottomSheetPresented = false
    @State private var selectedAction: ShiftAction?

    // 排休相關狀態
    @State private var isVacationEditMode = false
    @State private var vacationData = VacationData()
    @State private var vacationLimits = VacationLimits.weeklyOnly
    @State private var toastMessage = ""
    @State private var toastType: ToastView.ToastType = .info
    @State private var isToastShowing = false

    // 新增：排休模式選擇
    @State private var currentVacationMode: VacationMode = .monthly
    @State private var isVacationModeMenuPresented = false

    // 新增菜單顯示狀態
    @State private var isMenuPresented = false

    // 排班月份限制 - 使用當前月份
    @State private var availableVacationMonth: String = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM"
        return formatter.string(from: Date.now)
    }()
    @State private var availableVacationDays: Int = 4
    @State private var weeklyVacationLimit: Int = 2  // 新增：週排休限制

    // 優化後的統一 Picker 狀態
    @State private var isDatePickerPresented = false
    @State private var selectedYear = Calendar.current.component(.year, from: Date())
    @State private var selectedMonth = Calendar.current.component(.month, from: Date())

    var body: some View {
        ZStack {
            // Background
            Color.black.ignoresSafeArea()

            if isVacationEditMode {
                // 編輯模式：只顯示可編輯月份的簡化月曆
                editModeCalendarView()
            } else {
                // 一般模式：完整月曆
                normalModeCalendarView()
            }

            // FLOATING: Top buttons overlay (只在非編輯模式顯示)
            if !isVacationEditMode {
                topButtonsOverlay()
            }

            // FLOATING: Edit button overlay
            editButtonOverlay()

            // Toast 通知
            ToastView(message: toastMessage, type: toastType, isShowing: $isToastShowing)
                .zIndex(3)

            // 自定義菜單覆蓋層
            if isMenuPresented {
                customMenuOverlay()
            }
        }
        .sheet(isPresented: $isBottomSheetPresented) {
            BottomSheetView(
                isPresented: $isBottomSheetPresented,
                selectedAction: $selectedAction
            )
            .presentationDetents([.medium])
            .presentationDragIndicator(.hidden)
        }
        .sheet(isPresented: $isDatePickerPresented) {
            EnhancedDatePickerSheet(
                selectedYear: $selectedYear,
                selectedMonth: $selectedMonth,
                isPresented: $isDatePickerPresented,
                controller: controller
            )
        }
        .sheet(isPresented: $isVacationModeMenuPresented) {
            VacationModeSelectionSheet(
                currentMode: $currentVacationMode,
                weeklyLimit: $weeklyVacationLimit,
                monthlyLimit: $availableVacationDays,
                isPresented: $isVacationModeMenuPresented
            )
        }
        .onChange(of: selectedAction) { _, action in
            if let action = action {
                handleSelectedAction(action)
                selectedAction = nil
            }
        }
        .onAppear {
            loadVacationData()
        }
    }

    // MARK: - 一般模式月曆
    private func normalModeCalendarView() -> some View {
        FullPageScrollCalendarView(controller) { month in
            VStack(spacing: 0) {
                monthTitleView(month: month)
                weekdayHeadersView()

                GeometryReader { geometry in
                    let availableHeight = geometry.size.height
                    let cellHeight = max((availableHeight - 20) / 6, 70)

                    calendarGridView(month: month, cellHeight: cellHeight, isEditMode: false)
                }
            }
        }
    }

    // MARK: - 編輯模式簡化月曆
    private func editModeCalendarView() -> some View {
        VStack(spacing: 0) {
            // 簡化的編輯模式標題
            editModeHeader()

            // 直接顯示月曆
            GeometryReader { geometry in
                let availableHeight = geometry.size.height
                let cellHeight = max((availableHeight - 30) / 6, 80)

                VStack(spacing: 0) {
                    editModeWeekdayHeaders()
                    editModeCalendarGrid(cellHeight: cellHeight)
                }
            }

            // 編輯模式底部資訊
            editModeBottomInfo()
        }
    }

    // MARK: - 編輯模式標題（更新狀態顯示）
    private func editModeHeader() -> some View {
        VStack(spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("排休編輯")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundColor(.white)

                    HStack(spacing: 8) {
                        Text(formatMonthString(availableVacationMonth))
                            .font(.system(size: 16))
                            .foregroundColor(.white.opacity(0.8))

                        Text("•")
                            .font(.system(size: 12))
                            .foregroundColor(.white.opacity(0.6))

                        Text(currentVacationMode.rawValue)
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.blue.opacity(0.9))
                    }
                }

                Spacer()

                Button(action: {
                    withAnimation(.easeInOut(duration: 0.3)) {
                        isVacationEditMode = false
                    }
                }) {
                    HStack(spacing: 6) {
                        Image(systemName: "checkmark")
                            .font(.system(size: 14, weight: .semibold))
                        Text("完成")
                            .font(.system(size: 16, weight: .semibold))
                    }
                    .foregroundColor(.black)
                    .padding(.horizontal, 18)
                    .padding(.vertical, 12)
                    .background(Color.white)
                    .cornerRadius(22)
                }
            }

            // 排休資訊卡片（更新邏輯）
            HStack(spacing: 12) {
                infoCard(
                    title: vacationData.isSubmitted ? "已排休" : "可排休",
                    value: "\(availableVacationDays) 天",
                    icon: vacationData.isSubmitted ? "checkmark.circle.fill" : "calendar.badge.clock",
                    color: vacationData.isSubmitted ? .green : .blue
                )

                infoCard(
                    title: "已選擇",
                    value: "\(vacationData.selectedDates.count) 天",
                    icon: "checkmark.circle.fill",
                    color: .green
                )

                let remaining = availableVacationDays - vacationData.selectedDates.count
                infoCard(
                    title: "剩餘",
                    value: "\(max(0, remaining)) 天",
                    icon: "plus.circle",
                    color: remaining > 0 ? .orange : .red
                )
            }
        }
        .padding(.horizontal, 24)
        .padding(.top, 45)
        .padding(.bottom, 16)
    }

    private func infoCard(title: String, value: String, icon: String, color: Color) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 16))
                .foregroundColor(color)

            Text(title)
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(.white.opacity(0.8))

            Text(value)
                .font(.system(size: 14, weight: .bold))
                .foregroundColor(.white)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(Color.white.opacity(0.1))
        .cornerRadius(12)
    }

    // MARK: - 編輯模式週日標題
    private func editModeWeekdayHeaders() -> some View {
        HStack(spacing: 1) {
            ForEach(0..<7, id: \.self) { i in
                Text(DateFormatter().shortWeekdaySymbols[i].prefix(1))
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.white.opacity(0.8))
                    .frame(maxWidth: .infinity, alignment: .center)
                    .textCase(.uppercase)
            }
        }
        .padding(.horizontal, 8)
        .padding(.bottom, 12)
    }

    // MARK: - 編輯模式月曆格子
    private func editModeCalendarGrid(cellHeight: CGFloat) -> some View {
        let calendar = Calendar.current
        let components = availableVacationMonth.split(separator: "-")
        let year = Int(components[0]) ?? 2024
        let month = Int(components[1]) ?? 7

        let firstDay = calendar.date(from: DateComponents(year: year, month: month, day: 1))!
        let range = calendar.range(of: .day, in: .month, for: firstDay)!
        let daysInMonth = range.count
        let startingWeekday = calendar.component(.weekday, from: firstDay) - 1

        let gridItems = Array(repeating: GridItem(.flexible(), spacing: 2), count: 7)

        return LazyVGrid(columns: gridItems, alignment: .center, spacing: 2) {
            // 前面的空白日期
            ForEach(0..<startingWeekday, id: \.self) { index in
                Rectangle()
                    .fill(Color.clear)
                    .frame(height: cellHeight)
                    .id("empty-start-\(index)")
            }

            // 當月日期
            ForEach(1...daysInMonth, id: \.self) { day in
                editModeCalendarCell(day: day, cellHeight: cellHeight)
            }

            // 後面的空白日期填滿 6 週
            let totalCells = 42
            let usedCells = startingWeekday + daysInMonth
            ForEach(usedCells..<totalCells, id: \.self) { index in
                Rectangle()
                    .fill(Color.clear)
                    .frame(height: cellHeight)
                    .id("empty-end-\(index)")
            }
        }
        .background(Color.black)
        .padding(.horizontal, 8)
        .drawingGroup()
    }

    // MARK: - 編輯模式日期格子（"休"字下移）
    private func editModeCalendarCell(day: Int, cellHeight: CGFloat) -> some View {
        let dateString = String(format: "%@-%02d", availableVacationMonth, day)
        let isVacationSelected = vacationData.isDateSelected(dateString)
        let canSelect = canSelectForCurrentMode(day: day)

        return ZStack {
            // 基礎背景
            RoundedRectangle(cornerRadius: 8)
                .fill(Color(.systemGray6).opacity(0.3))
                .frame(height: cellHeight)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color(.systemGray5).opacity(0.2), lineWidth: 1)
                )

            // 週排休框線提示
            if shouldShowWeeklyHint(day: day, canSelect: canSelect, isSelected: isVacationSelected) {
                RoundedRectangle(cornerRadius: 8)
                    .stroke(
                        LinearGradient(
                            gradient: Gradient(colors: [
                                Color.green.opacity(0.6),
                                Color.blue.opacity(0.4)
                            ]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 2
                    )
                    .frame(height: cellHeight)
            }

            // 排休選擇背景
            if isVacationSelected {
                RoundedRectangle(cornerRadius: 8)
                    .fill(
                        LinearGradient(
                            gradient: Gradient(colors: [
                                Color.orange.opacity(0.95),
                                Color.orange.opacity(0.8),
                                Color.red.opacity(0.7)
                            ]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(height: cellHeight)
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color.orange.opacity(0.8), lineWidth: 1)
                    )
                    .shadow(color: .orange.opacity(0.3), radius: 3, x: 0, y: 1)
            }

            VStack(spacing: 4) {
                // 日期數字
                Text("\(day)")
                    .font(.system(size: min(cellHeight / 5, 14), weight: .medium))
                    .foregroundColor(isVacationSelected ? .white : .white)
                    .padding(.top, 8)

                // "休"字移到日期下方
                if isVacationSelected {
                    Text("休")
                        .font(.system(size: min(cellHeight / 8, 8), weight: .bold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 4)
                        .padding(.vertical, 1)
                        .background(
                            RoundedRectangle(cornerRadius: 3)
                                .fill(Color.red.opacity(0.8))
                        )
                }

                Spacer()
            }
        }
        .id("edit-\(day)")
        .onTapGesture {
            let impactFeedback = UIImpactFeedbackGenerator(style: .light)
            impactFeedback.impactOccurred()
            toggleVacationDate(dateString: dateString)
        }
    }

    // MARK: - 編輯模式底部資訊
    private func editModeBottomInfo() -> some View {
        VStack(spacing: 8) {
            if !vacationData.selectedDates.isEmpty {
                Text("已選擇: \(vacationData.selectedDates.count) 天")
                    .font(.system(size: 14))
                    .foregroundColor(.white.opacity(0.8))
            }
        }
        .padding(.horizontal, 24)
        .padding(.bottom, 15)
    }

    // MARK: - 根據當前模式判斷是否可選擇
    private func canSelectForCurrentMode(day: Int) -> Bool {
        switch currentVacationMode {
        case .monthly:
            return true // 月排休無週限制
        case .weekly, .monthlyWithWeeklyLimit:
            return canSelectForWeeklyLimit(day: day)
        }
    }

    private func shouldShowWeeklyHint(day: Int, canSelect: Bool, isSelected: Bool) -> Bool {
        switch currentVacationMode {
        case .monthly:
            return false // 月排休不顯示週提示
        case .weekly, .monthlyWithWeeklyLimit:
            return canSelect && !isSelected
        }
    }

    // MARK: - 週排休邏輯
    private func canSelectForWeeklyLimit(day: Int) -> Bool {
        let calendar = Calendar.current
        let components = availableVacationMonth.split(separator: "-")
        let year = Int(components[0]) ?? 2024
        let month = Int(components[1]) ?? 7

        guard let targetDate = calendar.date(from: DateComponents(year: year, month: month, day: day)) else {
            return false
        }

        let selectedInSameWeek = vacationData.selectedDates.compactMap { dateString -> Date? in
            let parts = dateString.split(separator: "-")
            guard parts.count == 3,
                  let y = Int(parts[0]),
                  let m = Int(parts[1]),
                  let d = Int(parts[2]) else { return nil }
            return calendar.date(from: DateComponents(year: y, month: m, day: d))
        }.filter { selectedDate in
            calendar.isDate(selectedDate, equalTo: targetDate, toGranularity: .weekOfYear)
        }

        return selectedInSameWeek.count < weeklyVacationLimit
    }

    private func handleSelectedAction(_ action: ShiftAction) {
        switch action {
        case .editVacation:
            let currentMonth = getCurrentMonthString()
            if currentMonth != availableVacationMonth {
                showToast("只能在 \(formatMonthString(availableVacationMonth)) 排休", type: .error)
                return
            }

            if vacationData.isSubmitted {
                showToast("本月排休已提交，無法修改", type: .error)
                return
            }
            withAnimation(.easeInOut(duration: 0.3)) {
                isVacationEditMode = true
            }
        case .clearVacation:
            let key = "VacationData_\(getCurrentMonthString())"
            UserDefaults.standard.removeObject(forKey: key)
            vacationData = VacationData()
            showToast("所有排休資料已清除", type: .info)
        }
    }

    // MARK: - 優化後的月份標題視圖（移除模式選擇按鈕）
    private func monthTitleView(month: CalendarMonth) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                // 月份和年份 - 統一的點擊區域
                Button(action: {
                    selectedMonth = month.month
                    selectedYear = month.year
                    withAnimation(.easeInOut(duration: 0.3)) {
                        isDatePickerPresented = true
                    }
                }) {
                    HStack(spacing: 8) {
                        Text(month.monthName)
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(.white)
                            .lineLimit(1)
                            .minimumScaleFactor(0.7)

                        Text("\(String(month.year))年")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.white.opacity(0.9))

                        Image(systemName: "chevron.down")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.white.opacity(0.7))
                    }
                }

                Spacer()

                // 編輯中標籤
                if isVacationEditMode {
                    HStack(spacing: 6) {
                        Circle()
                            .fill(Color.orange)
                            .frame(width: 8, height: 8)
                        Text("編輯中")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.orange)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Color.orange.opacity(0.2))
                    .cornerRadius(20)
                }
            }

            // 可排休標籤
            let currentDisplayMonth = String(format: "%04d-%02d", month.year, month.month)
            if currentDisplayMonth == availableVacationMonth && !isVacationEditMode {
                HStack(spacing: 6) {
                    Image(systemName: vacationData.isSubmitted ? "checkmark.circle.fill" : "calendar.badge.checkmark")
                        .font(.system(size: 12))
                        .foregroundColor(vacationData.isSubmitted ? .green : .green)
                    Text(vacationData.isSubmitted ? "已排休" : "可排休")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(vacationData.isSubmitted ? .green : .green)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background((vacationData.isSubmitted ? Color.green : Color.green).opacity(0.2))
                .cornerRadius(16)
            }
        }
        .padding(.horizontal, 24)
        .padding(.vertical, 20)
    }

    // MARK: - 統一星期標題與日期的字體大小
    private func weekdayHeadersView() -> some View {
        HStack(spacing: 1) {
            ForEach(0..<7, id: \.self) { i in
                Text(DateFormatter().shortWeekdaySymbols[i].prefix(1))
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.white.opacity(0.8))
                    .frame(maxWidth: .infinity, alignment: .center)
                    .textCase(.uppercase)
            }
        }
        .padding(.horizontal, 8)
        .padding(.bottom, 12)
    }

    private func calendarGridView(month: CalendarMonth, cellHeight: CGFloat, isEditMode: Bool) -> some View {
        let dates = month.getDaysInMonth(offset: 0)
        let gridItems = Array(repeating: GridItem(.flexible(), spacing: 2), count: 7)

        return LazyVGrid(columns: gridItems, alignment: .center, spacing: 2) {
            ForEach(0..<42, id: \.self) { index in
                normalModeCalendarCell(date: dates[index], month: month, cellHeight: cellHeight)
            }
        }
        .background(Color.black)
        .padding(.horizontal, 8)
        .drawingGroup()
    }

    // MARK: - 改進的日期格子（支援灰色日期選擇，"休"字下移，其他月份opacity）
    private func normalModeCalendarCell(date: CalendarDate, month: CalendarMonth, cellHeight: CGFloat) -> some View {
        let dateString = dateToString(date)
        let isSelected = controller.isDateSelected(date)
        let isVacationSelected = vacationData.isDateSelected(dateString) && date.isCurrentMonth == true

        return ZStack {
            Rectangle()
                .fill(Color.gray.opacity(0.05))
                .frame(height: cellHeight)

            // 選中狀態背景 - 支援灰色日期，其他月份加 opacity
            if isSelected && !isVacationEditMode {
                Rectangle()
                    .fill(Color.white.opacity(date.isCurrentMonth == true ? 1.0 : 0.6))  // 其他月份降低透明度
                    .frame(height: cellHeight)
            }

            if isVacationSelected {
                Rectangle()
                    .fill(
                        LinearGradient(
                            gradient: Gradient(colors: [
                                Color.orange.opacity(0.9),
                                Color.orange.opacity(0.7)
                            ]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(height: cellHeight)
            }

            VStack(spacing: 4) {
                // 日期數字
                Text("\(date.day)")
                    .font(.system(size: min(cellHeight / 5, 14), weight: .medium))
                    .foregroundColor(textColor(for: date, isSelected: isSelected, isVacationSelected: isVacationSelected))
                    .padding(.top, 8)

                // "休"字移到日期下方
                if isVacationSelected {
                    Text("休")
                        .font(.system(size: min(cellHeight / 8, 8), weight: .bold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 4)
                        .padding(.vertical, 1)
                        .background(Color.orange)
                        .cornerRadius(3)
                }

                Spacer()
            }
        }
        .onTapGesture {
            controller.selectDate(date)
        }
    }

    private func textColor(for date: CalendarDate, isSelected: Bool, isVacationSelected: Bool) -> Color {
        if isVacationSelected {
            return .white
        } else if isSelected && !isVacationEditMode {
            return .black
        } else if date.isCurrentMonth == true {
            return .white
        } else {
            return isSelected ? .black : .gray.opacity(0.4)
        }
    }

    // MARK: - 排休邏輯（根據模式調整）
    private func toggleVacationDate(dateString: String) {
        if vacationData.isSubmitted {
            showToast("已提交排休，無法修改", type: .error)
            return
        }

        var newVacationData = vacationData

        if newVacationData.isDateSelected(dateString) {
            newVacationData.removeDate(dateString)
        } else {
            // 檢查月排休限制
            if newVacationData.selectedDates.count >= availableVacationDays {
                showToast("已超過可排休天數上限 (\(availableVacationDays) 天)", type: .error)
                return
            }

            // 檢查週排休限制
            if currentVacationMode == .weekly || currentVacationMode == .monthlyWithWeeklyLimit {
                let day = Int(dateString.suffix(2)) ?? 1
                if !canSelectForWeeklyLimit(day: day) {
                    showToast("已超過本週排休上限 (\(weeklyVacationLimit) 天)", type: .error)
                    return
                }
            }

            newVacationData.addDate(dateString)
        }

        vacationData = newVacationData
        saveVacationData()
    }

    private func dateToString(_ date: CalendarDate) -> String {
        return String(format: "%04d-%02d-%02d", date.year, date.month, date.day)
    }

    private func formatMonthString(_ monthString: String) -> String {
        let components = monthString.split(separator: "-")
        if components.count == 2,
           let year = Int(components[0]),
           let month = Int(components[1]) {
            return "\(year)年\(month)月"
        }
        return monthString
    }

    private func topButtonsOverlay() -> some View {
        VStack {
            HStack {
                Spacer()
                Button(action: {}) {
                    Image(systemName: "square.and.arrow.up")
                        .font(.system(size: 20))
                        .foregroundColor(.white)
                        .padding(12)
                        .background(.ultraThinMaterial)
                        .clipShape(Circle())
                }
                Button(action: {}) {
                    Image(systemName: "line.3.horizontal")
                        .font(.system(size: 20))
                        .foregroundColor(.white)
                        .padding(12)
                        .background(.ultraThinMaterial)
                        .clipShape(Circle())
                }
            }
            .padding(.horizontal, 24)
            .padding(.top, 20)

            Spacer()
        }
    }

    // MARK: - 優化的編輯按鈕
    private func editButtonOverlay() -> some View {
        VStack {
            Spacer()
            HStack {
                Spacer()

                if isVacationEditMode {
                    VStack(spacing: 12) {
                        if !vacationData.selectedDates.isEmpty && !vacationData.isSubmitted {
                            Button(action: submitVacation) {
                                HStack(spacing: 8) {
                                    Image(systemName: "paperplane.fill")
                                        .font(.system(size: 14, weight: .semibold))
                                    Text("提交排休")
                                        .font(.system(size: 16, weight: .semibold))
                                }
                                .foregroundColor(.white)
                                .padding(.horizontal, 24)
                                .padding(.vertical, 16)
                                .background(
                                    LinearGradient(
                                        gradient: Gradient(colors: [Color.blue, Color.blue.opacity(0.8)]),
                                        startPoint: .leading,
                                        endPoint: .trailing
                                    )
                                )
                                .cornerRadius(28)
                                .shadow(color: .blue.opacity(0.4), radius: 12, x: 0, y: 6)
                            }
                        }

                        if !vacationData.selectedDates.isEmpty {
                            Button(action: clearCurrentSelection) {
                                HStack(spacing: 6) {
                                    Image(systemName: "trash")
                                        .font(.system(size: 12, weight: .medium))
                                    Text("清除")
                                        .font(.system(size: 14, weight: .medium))
                                }
                                .foregroundColor(.red)
                                .padding(.horizontal, 18)
                                .padding(.vertical, 12)
                                .background(.ultraThinMaterial)
                                .cornerRadius(22)
                                .shadow(color: .black.opacity(0.1), radius: 6, x: 0, y: 3)
                            }
                        }
                    }
                } else {
                    Button(action: {
                        isBottomSheetPresented = true
                    }) {
                        Image(systemName: "pencil")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.black)
                            .padding(15)
                            .background(Color.white)
                            .clipShape(Circle())
                            .shadow(color: .black.opacity(0.15), radius: 8, x: 0, y: 4)
                    }
                }
            }
            .padding(.bottom, 30)
            .padding(.trailing, 30)
        }
    }

    // MARK: - 輔助方法
    private func submitVacation() {
        vacationData.isSubmitted = true
        vacationData.currentMonth = getCurrentMonthString()
        saveVacationData()
        showToast("排休已成功提交！", type: .success)

        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            withAnimation(.easeInOut(duration: 0.3)) {
                isVacationEditMode = false
            }
        }
    }

    private func clearCurrentSelection() {
        vacationData.selectedDates.removeAll()
        saveVacationData()
    }

    private func getCurrentMonthString() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM"
        return formatter.string(from: Date())
    }

    private func showToast(_ message: String, type: ToastView.ToastType) {
        toastMessage = message
        toastType = type
        withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) {
            isToastShowing = true
        }
    }

    private func saveVacationData() {
        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(vacationData) {
            UserDefaults.standard.set(encoded, forKey: "VacationData_\(getCurrentMonthString())")
        }
    }

    private func loadVacationData() {
        let key = "VacationData_\(getCurrentMonthString())"
        if let data = UserDefaults.standard.data(forKey: key),
           let decoded = try? JSONDecoder().decode(VacationData.self, from: data) {
            vacationData = decoded
        }
    }

    // MARK: - 自定義菜單覆蓋層
    private func customMenuOverlay() -> some View {
        ZStack {
            // 半透明背景
            Color.black.opacity(0.3)
                .ignoresSafeArea()
                .onTapGesture {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        isMenuPresented = false
                    }
                }

            VStack {
                HStack {
                    Spacer()

                    // 菜單內容
                    VStack(spacing: 0) {
                        // 排休模式區域
                        VStack(spacing: 0) {
                            // 區域標題
                            HStack {
                                Image(systemName: "calendar.badge.clock")
                                    .font(.system(size: 16, weight: .medium))
                                    .foregroundColor(.white.opacity(0.9))
                                Text("排休模式")
                                    .font(.system(size: 18, weight: .semibold))
                                    .foregroundColor(.white)
                                Spacer()
                            }
                            .padding(.horizontal, 20)
                            .padding(.top, 20)
                            .padding(.bottom, 16)

                            // 模式選項
                            VStack(spacing: 0) {
                                ForEach(VacationMode.allCases, id: \.self) { mode in
                                    menuItem(
                                        icon: mode.icon,
                                        title: mode.rawValue,
                                        isSelected: currentVacationMode == mode
                                    ) {
                                        currentVacationMode = mode
                                        withAnimation(.easeInOut(duration: 0.2)) {
                                            isMenuPresented = false
                                        }
                                    }

                                    if mode != VacationMode.allCases.last {
                                        Divider()
                                            .background(Color.white.opacity(0.1))
                                            .padding(.leading, 60)
                                    }
                                }
                            }

                            Divider()
                                .background(Color.white.opacity(0.2))
                                .padding(.vertical, 8)

                            // 排休設定按鈕
                            menuItem(
                                icon: "gear",
                                title: "排休設定",
                                isSelected: false
                            ) {
                                isVacationModeMenuPresented = true
                                withAnimation(.easeInOut(duration: 0.2)) {
                                    isMenuPresented = false
                                }
                            }
                        }

                        Divider()
                            .background(Color.white.opacity(0.3))
                            .padding(.vertical, 8)

                        // 其他功能區域
                        VStack(spacing: 0) {
                            menuItem(icon: "square.and.arrow.up", title: "分享排班表", isSelected: false) {
                                // TODO: 分享功能
                                withAnimation(.easeInOut(duration: 0.2)) {
                                    isMenuPresented = false
                                }
                            }

                            Divider()
                                .background(Color.white.opacity(0.1))
                                .padding(.leading, 60)

                            menuItem(icon: "square.and.arrow.down", title: "匯出資料", isSelected: false) {
                                // TODO: 匯出功能
                                withAnimation(.easeInOut(duration: 0.2)) {
                                    isMenuPresented = false
                                }
                            }

                            Divider()
                                .background(Color.white.opacity(0.1))
                                .padding(.leading, 60)

                            menuItem(icon: "questionmark.circle", title: "關於", isSelected: false) {
                                // TODO: 關於頁面
                                withAnimation(.easeInOut(duration: 0.2)) {
                                    isMenuPresented = false
                                }
                            }
                        }
                        .padding(.bottom, 16)
                    }
                    .background(
                        RoundedRectangle(cornerRadius: 16)
                            .fill(.ultraThinMaterial)
                            .background(Color.black.opacity(0.8))
                    )
                    .frame(width: 280)
                    .shadow(color: .black.opacity(0.3), radius: 20, x: 0, y: 10)
                }
                .padding(.horizontal, 24)
                .padding(.top, 80)

                Spacer()
            }
        }
        .transition(.opacity.combined(with: .scale(scale: 0.95, anchor: .topTrailing)))
        .zIndex(4)
    }

    // MARK: - 菜單項目
    private func menuItem(
        icon: String,
        title: String,
        isSelected: Bool,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            HStack(spacing: 16) {
                Image(systemName: icon)
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(isSelected ? .blue : .white.opacity(0.9))
                    .frame(width: 24, height: 24)

                Text(title)
                    .font(.system(size: 16, weight: isSelected ? .semibold : .medium))
                    .foregroundColor(isSelected ? .blue : .white)

                Spacer()

                if isSelected {
                    Image(systemName: "checkmark")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.blue)
                }
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 14)
            .background(
                isSelected ?
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color.blue.opacity(0.15))
                        .padding(.horizontal, 8) :
                    nil
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - 排休模式選擇 Sheet
struct VacationModeSelectionSheet: View {
    @Binding var currentMode: VacationMode
    @Binding var weeklyLimit: Int
    @Binding var monthlyLimit: Int
    @Binding var isPresented: Bool

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // 說明文字
                VStack(spacing: 8) {
                    Text("選擇排休模式")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(.primary)

                    Text("選擇適合的排休規則來測試不同的UI效果")
                        .font(.system(size: 14))
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                }
                .padding(.top, 20)
                .padding(.bottom, 30)

                // 模式選擇
                VStack(spacing: 16) {
                    ForEach(VacationMode.allCases, id: \.self) { mode in
                        VacationModeCard(
                            mode: mode,
                            isSelected: currentMode == mode,
                            weeklyLimit: weeklyLimit,
                            monthlyLimit: monthlyLimit
                        ) {
                            currentMode = mode
                        }
                    }
                }
                .padding(.horizontal, 20)

                // 設定區域
                VStack(spacing: 20) {
                    Divider()
                        .padding(.vertical, 10)

                    VStack(spacing: 16) {
                        // 月排休天數設定
                        HStack {
                            Text("月排休天數")
                                .font(.system(size: 16, weight: .medium))
                                .foregroundColor(.primary)

                            Spacer()

                            Stepper(value: $monthlyLimit, in: 1...31) {
                                Text("\(monthlyLimit) 天")
                                    .font(.system(size: 16, weight: .semibold))
                                    .foregroundColor(.blue)
                            }
                        }

                        // 週排休天數設定（僅在相關模式下顯示）
                        if currentMode == .weekly || currentMode == .monthlyWithWeeklyLimit {
                            HStack {
                                Text("週排休上限")
                                    .font(.system(size: 16, weight: .medium))
                                    .foregroundColor(.primary)

                                Spacer()

                                Stepper(value: $weeklyLimit, in: 1...7) {
                                    Text("\(weeklyLimit) 天")
                                        .font(.system(size: 16, weight: .semibold))
                                        .foregroundColor(.green)
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                }

                Spacer()
            }
            .navigationTitle("排休設定")
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarBackButtonHidden()
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消") {
                        isPresented = false
                    }
                    .foregroundColor(.secondary)
                }

                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成") {
                        isPresented = false
                    }
                    .foregroundColor(.blue)
                    .fontWeight(.semibold)
                }
            }
        }
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
    }
}

// MARK: - 排休模式卡片
struct VacationModeCard: View {
    let mode: VacationMode
    let isSelected: Bool
    let weeklyLimit: Int
    let monthlyLimit: Int
    let onTap: () -> Void

    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 16) {
                // 圖示
                Image(systemName: mode.icon)
                    .font(.system(size: 24, weight: .medium))
                    .foregroundColor(isSelected ? .white : .blue)
                    .frame(width: 40, height: 40)
                    .background(
                        Circle()
                            .fill(isSelected ? Color.blue : Color.blue.opacity(0.1))
                    )

                // 內容
                VStack(alignment: .leading, spacing: 4) {
                    Text(mode.rawValue)
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(isSelected ? .white : .primary)

                    Text(mode.description)
                        .font(.system(size: 13))
                        .foregroundColor(isSelected ? .white.opacity(0.9) : .secondary)
                        .multilineTextAlignment(.leading)

                    // 顯示當前設定
                    if mode == .weekly {
                        Text("每週最多 \(weeklyLimit) 天")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(isSelected ? .white.opacity(0.8) : .green)
                    } else if mode == .monthly {
                        Text("每月最多 \(monthlyLimit) 天")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(isSelected ? .white.opacity(0.8) : .blue)
                    } else if mode == .monthlyWithWeeklyLimit {
                        Text("每月 \(monthlyLimit) 天，每週最多 \(weeklyLimit) 天")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(isSelected ? .white.opacity(0.8) : .orange)
                    }
                }

                Spacer()

                // 選中指示器
                if isSelected {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 20))
                        .foregroundColor(.white)
                }
            }
            .padding(16)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(isSelected ? Color.blue : Color(.systemBackground))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(isSelected ? Color.clear : Color(.systemGray4), lineWidth: 1)
                    )
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - 美化的原生 Sheet 日期選擇器
struct EnhancedDatePickerSheet: View {
    @Binding var selectedYear: Int
    @Binding var selectedMonth: Int
    @Binding var isPresented: Bool
    let controller: CalendarController

    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color(.systemBackground),
                        Color(.systemGray6).opacity(0.3)
                    ]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()

                VStack(spacing: 0) {
                    VStack(spacing: 0) {
                        HStack(spacing: 0) {
                            VStack(spacing: 12) {
                                HStack {
                                    Image(systemName: "calendar")
                                        .font(.system(size: 14, weight: .medium))
                                        .foregroundColor(.blue)
                                    Text("年份")
                                        .font(.system(size: 15, weight: .semibold))
                                        .foregroundColor(.primary)
                                }
                                .padding(.top, 16)

                                Picker("年份", selection: $selectedYear) {
                                    ForEach(1900...2100, id: \.self) { year in
                                        Text(String(year))
                                            .font(.system(size: 22, weight: .medium))
                                            .tag(year)
                                    }
                                }
                                .pickerStyle(WheelPickerStyle())
                                .frame(height: 200)
                                .clipped()
                            }
                            .frame(maxWidth: .infinity)
                            .background(
                                RoundedRectangle(cornerRadius: 16)
                                    .fill(Color(.systemBackground))
                                    .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
                            )
                            .padding(.leading, 20)
                            .padding(.trailing, 8)

                            VStack(spacing: 12) {
                                HStack {
                                    Image(systemName: "calendar.circle")
                                        .font(.system(size: 14, weight: .medium))
                                        .foregroundColor(.green)
                                    Text("月份")
                                        .font(.system(size: 15, weight: .semibold))
                                        .foregroundColor(.primary)
                                }
                                .padding(.top, 16)

                                Picker("月份", selection: $selectedMonth) {
                                    ForEach(1...12, id: \.self) { month in
                                        Text("\(month)月")
                                            .font(.system(size: 22, weight: .medium))
                                            .tag(month)
                                    }
                                }
                                .pickerStyle(WheelPickerStyle())
                                .frame(height: 200)
                                .clipped()
                            }
                            .frame(maxWidth: .infinity)
                            .background(
                                RoundedRectangle(cornerRadius: 16)
                                    .fill(Color(.systemBackground))
                                    .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
                            )
                            .padding(.trailing, 20)
                            .padding(.leading, 8)
                        }
                        .padding(.bottom, 20)
                    }

                    VStack(spacing: 12) {
                        Text("快速選擇")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.secondary)

                        HStack(spacing: 12) {
                            quickSelectButton(title: "本月", action: {
                                let now = Date()
                                selectedYear = Calendar.current.component(.year, from: now)
                                selectedMonth = Calendar.current.component(.month, from: now)
                            })

                            quickSelectButton(title: "下月", action: {
                                let calendar = Calendar.current
                                let nextMonth = calendar.date(byAdding: .month, value: 1, to: Date()) ?? Date()
                                selectedYear = calendar.component(.year, from: nextMonth)
                                selectedMonth = calendar.component(.month, from: nextMonth)
                            })

                            quickSelectButton(title: "上月", action: {
                                let calendar = Calendar.current
                                let lastMonth = calendar.date(byAdding: .month, value: -1, to: Date()) ?? Date()
                                selectedYear = calendar.component(.year, from: lastMonth)
                                selectedMonth = calendar.component(.month, from: lastMonth)
                            })
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 30)

                    Spacer()
                }
            }
            .navigationTitle("選擇日期")
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarBackButtonHidden()
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.3)) {
                            isPresented = false
                        }
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: "xmark.circle.fill")
                                .font(.system(size: 16))
                            Text("取消")
                                .font(.system(size: 16))
                        }
                        .foregroundColor(.secondary)
                    }
                }

                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        controller.navigateToMonth(year: selectedYear, month: selectedMonth)
                        withAnimation(.easeInOut(duration: 0.3)) {
                            isPresented = false
                        }
                    }) {
                        HStack(spacing: 6) {
                            Text("前往")
                                .font(.system(size: 16, weight: .semibold))
                            Image(systemName: "arrow.right.circle.fill")
                                .font(.system(size: 16))
                        }
                        .foregroundColor(.blue)
                    }
                }
            }
        }
        .presentationDetents([.fraction(0.55)])
        .presentationDragIndicator(.visible)
    }

    private func quickSelectButton(title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(.blue)
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .background(
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.blue.opacity(0.1))
                        .overlay(
                            RoundedRectangle(cornerRadius: 20)
                                .stroke(Color.blue.opacity(0.3), lineWidth: 1)
                        )
                )
        }
        .buttonStyle(PlainButtonStyle())
    }
}

#Preview {
    EmployeeCalendarView()
}
