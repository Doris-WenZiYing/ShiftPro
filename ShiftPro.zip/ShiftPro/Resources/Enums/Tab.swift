//
//  Tab.swift
//  ShiftPro
//
//  Created by Doris Wen on 2025/7/9.
//

import Foundation

enum Tab {
    case calendar, reports, templates, more
}
