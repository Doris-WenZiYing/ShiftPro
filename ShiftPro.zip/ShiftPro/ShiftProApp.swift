//
//  ShiftProApp.swift
//  ShiftPro
//
//  Created by Doris Wen on 2025/7/8.
//

import SwiftUI

@main
struct ShiftProApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
